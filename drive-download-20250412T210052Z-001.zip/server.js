
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

const USERS_FILE = 'users.json';

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    let users = fs.existsSync(USERS_FILE) ? JSON.parse(fs.readFileSync(USERS_FILE)) : [];
    if (users.find(u => u.username === username)) {
        return res.send('User already exists.');
    }
    users.push({ username, password });
    fs.writeFileSync(USERS_FILE, JSON.stringify(users));
    res.send('Registration successful. <a href="/login.html">Login now</a>');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    let users = fs.existsSync(USERS_FILE) ? JSON.parse(fs.readFileSync(USERS_FILE)) : [];
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        res.send(`Welcome, ${username}`);
    } else {
        res.send('Invalid credentials.');
    }
});

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});


const REQUESTS_FILE = 'requests.json';

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/request.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'request.html'));
});

app.post('/submit-request', (req, res) => {
    const { clientName, email, category, details } = req.body;
    let requests = fs.existsSync(REQUESTS_FILE) ? JSON.parse(fs.readFileSync(REQUESTS_FILE)) : [];
    requests.push({ clientName, email, category, details, date: new Date().toISOString() });
    fs.writeFileSync(REQUESTS_FILE, JSON.stringify(requests));
    res.send('Request submitted successfully. <a href="/dashboard">Back to Dashboard</a>');
});


app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/view-requests', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'view-requests.html'));
});

app.get('/payment', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'payment.html'));
});

app.get('/track-order', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'track-order.html'));
});

app.post('/assign-freelancer', (req, res) => {
    const { index, freelancer, status } = req.body;
    let requests = fs.existsSync(REQUESTS_FILE) ? JSON.parse(fs.readFileSync(REQUESTS_FILE)) : [];
    if (requests[index]) {
        requests[index].freelancer = freelancer;
        requests[index].status = status;
    }
    fs.writeFileSync(REQUESTS_FILE, JSON.stringify(requests));
    res.redirect('/view-requests');
});

app.get('/api/requests', (req, res) => {
    const requests = fs.existsSync(REQUESTS_FILE) ? JSON.parse(fs.readFileSync(REQUESTS_FILE)) : [];
    res.json(requests);
});

app.post('/track-order', (req, res) => {
    const { email } = req.body;
    const requests = fs.existsSync(REQUESTS_FILE) ? JSON.parse(fs.readFileSync(REQUESTS_FILE)) : [];
    const matches = requests.filter(r => r.email === email);
    if (matches.length > 0) {
        let html = '<h2>Your Orders</h2>';
        matches.forEach((r, i) => {
            html += `<p><strong>Service:</strong> ${r.category}<br><strong>Status:</strong> ${r.status || 'Pending'}</p><hr>`;
        });
        res.send(html + '<a href="/track-order">Back</a>');
    } else {
        res.send('No orders found for this email. <a href="/track-order">Back</a>');
    }
});


// Admin login security
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "admin123";

app.get('/admin-login', (req, res) => {
    res.send('<form method="POST" action="/admin-login"><input name="username" placeholder="Username"/><input name="password" type="password" placeholder="Password"/><button type="submit">Login</button></form>');
});

app.post('/admin-login', (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        res.redirect('/admin');
    } else {
        res.send('Invalid admin credentials. <a href="/admin-login">Try Again</a>');
    }
});

// Simulated Stripe Payment
app.post('/pay', (req, res) => {
    const { email, amount } = req.body;
    // Normally you would use Stripe API here with secret keys
    res.send(\`Payment of $${amount} from \${email} processed successfully (simulation). <a href="/">Home</a>\`);
});

// Simulated Email Notification (Console log)
function sendEmail(to, subject, message) {
    console.log("=== EMAIL NOTIFICATION ===");
    console.log("To:", to);
    console.log("Subject:", subject);
    console.log("Message:", message);
}

app.post('/submit-request', (req, res) => {
    const { clientName, email, category, details } = req.body;
    let requests = fs.existsSync(REQUESTS_FILE) ? JSON.parse(fs.readFileSync(REQUESTS_FILE)) : [];
    const newRequest = { clientName, email, category, details, date: new Date().toISOString() };
    requests.push(newRequest);
    fs.writeFileSync(REQUESTS_FILE, JSON.stringify(requests));
    
    // Email notification simulation
    sendEmail(email, "Request Received", \`Thank you \${clientName}, your \${category} request has been received.\`);

    res.send('Request submitted successfully. <a href="/dashboard">Back to Dashboard</a>');
});
